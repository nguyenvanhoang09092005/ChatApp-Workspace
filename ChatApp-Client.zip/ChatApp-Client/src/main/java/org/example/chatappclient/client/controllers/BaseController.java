package org.example.chatappclient.client.controllers;

public class BaseController {
}
