package org.example.chatappclient.client.controllers.auth;

public class ProfileController {
}
