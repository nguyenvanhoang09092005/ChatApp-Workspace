package org.example.chatappclient.client.utils.network;

public class ConnectionManager {
}
