package org.example.chatappclient.client.services;

public class ContactService {
}
