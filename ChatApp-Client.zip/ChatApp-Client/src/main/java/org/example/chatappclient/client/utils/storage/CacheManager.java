package org.example.chatappclient.client.utils.storage;

public class CacheManager {
}
