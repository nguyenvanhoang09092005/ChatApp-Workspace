package org.example.chatappclient.client.controllers.main;

public class ContactController {
}
