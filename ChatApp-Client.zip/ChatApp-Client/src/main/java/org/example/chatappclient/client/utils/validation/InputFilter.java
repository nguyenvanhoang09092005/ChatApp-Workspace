package org.example.chatappclient.client.utils.validation;

public class InputFilter {
}
