package org.example.chatappclient.client.utils.ui;

public class AnimationUtil {
}
