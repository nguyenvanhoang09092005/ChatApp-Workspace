package org.example.chatappclient.client;

public class ServerConnection {
}
