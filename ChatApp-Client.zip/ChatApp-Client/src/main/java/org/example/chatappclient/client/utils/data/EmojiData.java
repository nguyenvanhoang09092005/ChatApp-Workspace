package org.example.chatappclient.client.utils.data;

import java.util.*;

public class EmojiData {

    // ==================== EMOJI CATEGORIES ====================

    public static final Map<String, List<String>> EMOJI_CATEGORIES = new LinkedHashMap<>();

    static {
        // 😀 Smileys & People
        EMOJI_CATEGORIES.put("Cảm xúc", Arrays.asList(
                "😀", "😃", "😄", "😁", "😆", "😅", "🤣", "😂",
                "🙂", "🙃", "😉", "😊", "😇", "🥰", "😍", "🤩",
                "😘", "😗", "☺️", "😚", "😙", "🥲", "😋", "😛",
                "😜", "🤪", "😝", "🤑", "🤗", "🤭", "🤫", "🤔",
                "🤐", "🤨", "😐", "😑", "😶", "😏", "😒", "🙄",
                "😬", "🤥", "😌", "😔", "😪", "🤤", "😴", "😷",
                "🤒", "🤕", "🤢", "🤮", "🤧", "🥵", "🥶", "🥴",
                "😵", "🤯", "🤠", "🥳", "🥸", "😎", "🤓", "🧐"
        ));

        // ❤️ Hearts & Love
        EMOJI_CATEGORIES.put("Trái tim", Arrays.asList(
                "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍",
                "🤎", "💔", "❣️", "💕", "💞", "💓", "💗", "💖",
                "💘", "💝", "💟", "☮️", "✝️", "☪️", "🕉️", "☸️",
                "✡️", "🔯", "🕎", "☯️", "☦️", "🛐", "⛎", "♈",
                "♉", "♊", "♋", "♌", "♍", "♎", "♏", "♐",
                "♑", "♒", "♓", "🆔", "⚛️", "🉑", "☢️", "☣️"
        ));

        // 😢 Sad & Crying
        EMOJI_CATEGORIES.put("Buồn & Khóc", Arrays.asList(
                "😥", "😢", "😭", "😤", "😠", "😡", "🤬", "😈",
                "👿", "💀", "☠️", "💩", "🤡", "👹", "👺", "👻",
                "👽", "👾", "🤖", "😺", "😸", "😹", "😻", "😼",
                "😽", "🙀", "😿", "😾"
        ));

        // 👋 Hand Gestures
        EMOJI_CATEGORIES.put("Cử chỉ tay", Arrays.asList(
                "👋", "🤚", "🖐️", "✋", "🖖", "👌", "🤌", "🤏",
                "✌️", "🤞", "🤟", "🤘", "🤙", "👈", "👉", "👆",
                "🖕", "👇", "☝️", "👍", "👎", "✊", "👊", "🤛",
                "🤜", "👏", "🙌", "👐", "🤲", "🤝", "🙏", "✍️",
                "💅", "🤳", "💪", "🦾", "🦿", "🦵", "🦶", "👂"
        ));

        // 🐶 Animals
        EMOJI_CATEGORIES.put("Động vật", Arrays.asList(
                "🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼",
                "🐨", "🐯", "🦁", "🐮", "🐷", "🐽", "🐸", "🐵",
                "🙈", "🙉", "🙊", "🐒", "🐔", "🐧", "🐦", "🐤",
                "🐣", "🐥", "🦆", "🦅", "🦉", "🦇", "🐺", "🐗",
                "🐴", "🦄", "🐝", "🐛", "🦋", "🐌", "🐞", "🐜",
                "🦟", "🦗", "🕷️", "🕸️", "🦂", "🐢", "🐍", "🦎"
        ));

        // 🍔 Food & Drink
        EMOJI_CATEGORIES.put("Đồ ăn & uống", Arrays.asList(
                "🍏", "🍎", "🍐", "🍊", "🍋", "🍌", "🍉", "🍇",
                "🍓", "🫐", "🍈", "🍒", "🍑", "🥭", "🍍", "🥥",
                "🥝", "🍅", "🍆", "🥑", "🥦", "🥬", "🥒", "🌶️",
                "🫑", "🌽", "🥕", "🫒", "🧄", "🧅", "🥔", "🍠",
                "🥐", "🥯", "🍞", "🥖", "🥨", "🧀", "🥚", "🍳",
                "🧈", "🥞", "🧇", "🥓", "🥩", "🍗", "🍖", "🦴"
        ));

        // ⚽ Sports & Activities
        EMOJI_CATEGORIES.put("Thể thao", Arrays.asList(
                "⚽", "🏀", "🏈", "⚾", "🥎", "🎾", "🏐", "🏉",
                "🥏", "🎱", "🪀", "🏓", "🏸", "🏒", "🏑", "🥍",
                "🏏", "🥅", "⛳", "🪁", "🏹", "🎣", "🤿", "🥊",
                "🥋", "🎽", "🛹", "🛼", "🛷", "⛸️", "🥌", "🎿",
                "⛷️", "🏂", "🪂", "🏋️", "🤼", "🤸", "🤺", "⛹️"
        ));

        // 🚗 Travel & Places
        EMOJI_CATEGORIES.put("Du lịch", Arrays.asList(
                "🚗", "🚕", "🚙", "🚌", "🚎", "🏎️", "🚓", "🚑",
                "🚒", "🚐", "🛻", "🚚", "🚛", "🚜", "🦯", "🦽",
                "🦼", "🛴", "🚲", "🛵", "🏍️", "🛺", "🚨", "🚔",
                "🚍", "🚘", "🚖", "🚡", "🚠", "🚟", "🚃", "🚋",
                "🚞", "🚝", "🚄", "🚅", "🚈", "🚂", "🚆", "🚇"
        ));

        // 🎵 Objects
        EMOJI_CATEGORIES.put("Đồ vật", Arrays.asList(
                "⌚", "📱", "📲", "💻", "⌨️", "🖥️", "🖨️", "🖱️",
                "🖲️", "🕹️", "🗜️", "💽", "💾", "💿", "📀", "📼",
                "📷", "📸", "📹", "🎥", "📽️", "🎞️", "📞", "☎️",
                "📟", "📠", "📺", "📻", "🎙️", "🎚️", "🎛️", "🧭",
                "⏱️", "⏲️", "⏰", "🕰️", "⌛", "⏳", "📡", "🔋"
        ));

        // 💯 Symbols
        EMOJI_CATEGORIES.put("Ký hiệu", Arrays.asList(
                "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍",
                "🤎", "💔", "❣️", "💕", "💞", "💓", "💗", "💖",
                "💘", "💝", "💟", "✔️", "✅", "☑️", "✖️", "❌",
                "❎", "➕", "➖", "➗", "✏️", "📝", "💯", "🔥",
                "⭐", "🌟", "✨", "💫", "⚡", "💥", "💢", "💨"
        ));

        // 🏁 Flags
        EMOJI_CATEGORIES.put("Cờ", Arrays.asList(
                "🏁", "🚩", "🎌", "🏴", "🏳️", "🏳️‍🌈", "🏳️‍⚧️", "🏴‍☠️",
                "🇻🇳", "🇺🇸", "🇬🇧", "🇯🇵", "🇰🇷", "🇨🇳", "🇫🇷", "🇩🇪",
                "🇮🇹", "🇪🇸", "🇷🇺", "🇧🇷", "🇦🇺", "🇨🇦", "🇮🇳", "🇹🇭",
                "🇸🇬", "🇲🇾", "🇵🇭", "🇮🇩", "🇱🇦", "🇰🇭", "🇲🇲", "🇧🇳"
        ));
    }

    // ==================== FREQUENTLY USED ====================

    public static List<String> getFrequentlyUsed() {
        return Arrays.asList(
                "😀", "😂", "🤣", "😍", "😭", "😊", "🥰", "👍",
                "❤️", "😘", "😎", "✨", "🔥", "👏", "🙏", "💯",
                "😢", "🤔", "😅", "🥺", "😴", "🤗", "💪", "👌"
        );
    }

    // ==================== SEARCH ====================

    public static List<String> searchEmojis(String keyword) {
        List<String> results = new ArrayList<>();
        String lower = keyword.toLowerCase();

        for (Map.Entry<String, List<String>> entry : EMOJI_CATEGORIES.entrySet()) {
            String category = entry.getKey().toLowerCase();
            if (category.contains(lower)) {
                results.addAll(entry.getValue());
            }
        }

        return results;
    }

    // ==================== GETTERS ====================

    public static List<String> getAllEmojis() {
        List<String> all = new ArrayList<>();
        for (List<String> emojis : EMOJI_CATEGORIES.values()) {
            all.addAll(emojis);
        }
        return all;
    }

    public static List<String> getCategoryNames() {
        return new ArrayList<>(EMOJI_CATEGORIES.keySet());
    }

    public static List<String> getEmojisForCategory(String category) {
        return EMOJI_CATEGORIES.getOrDefault(category, new ArrayList<>());
    }
}